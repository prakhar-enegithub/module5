# Module 1 Assignment

Coursera course: [HTML, CSS, and Javascript for Web Developers](https://www.coursera.org/learn/html-css-javascript-for-web-developers)

**Module 1 does NOT contain a coding assignment. All you have to do is pass the quiz at the end of module 1 on the Coursera platform.**
