YOU HAVE A CHOICE!

If you want a slightly more challenging assignment, use the code in the “harder”
folder as your starting point. If you want a slightly less challenging
assignment, use the code in the “easier” folder as your starting point.

The difference between the two starting points is that in the “easier”
starting point, there are a few steps that are already completed for you.

Harder:
If you want a slightly more challenging assignment, copy all the contents of
the ‘harder’ folder into your newly created solutions container folder for
this assignment, e.g., ‘module4-solution’.

Easier:
If you want a slightly less challenging assignment, copy all the contents of
the ‘easier’ folder into your newly created solutions container folder for
this assignment, e.g., ‘module4-solution’.
